module.exports = class extends think.Controller {
  async __before() {
    // 根据token值获取用户id
    think.token = this.ctx.header['x-hioshop-token'] || '';
    const tokenSerivce = think.service('token', 'admin');
    think.userId = await tokenSerivce.getUserId();
    // 只允许登录操作
    if (this.ctx.controller != 'auth') {
      if (think.userId <= 0 || think.userId == undefined) {
        return this.fail(401, '请先登录');
      }
    }
  }
};